# -*- coding: utf-8 -*-
import scrapy
from news.items import NewsProjectItem
from news.middlewares import Deal_Content
import urllib.parse

class nongyeSpider(scrapy.Spider):
    name = 'China_nongye_info'
    allowed_domains = ['www.agri.cn']    #允许的页面最好不要定义  http://  这样的
    base_url = 'http://www.agri.cn/V20/ZX/nyyw/'
    start_urls = ['http://www.agri.cn/V20/ZX/nyyw/']

    #中国农业信息网
    def parse(self, response):
        id, pid= Deal_Content.sql_read(response.url)

        list_news = response.xpath("//td[@class = 'bk_7']//table[@width='659']")
        for news in list_news:
            time = news.xpath(".//td[@width='120']/text()").extract_first()
            detail_url = self.base_url + news.xpath(".//a/@href").extract_first().replace("./", '')
            #print("detail_url",detail_url)
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time':time,'detail_url':detail_url,'id':id,'pid':pid})  #进入详细页面

    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = 101

        item['pid'] = 1


        # 首页的url
        item['url'] = self.start_urls[0]
        #print("主页的url", item['url'])

        #首页的每一个新闻url
        item['title_url'] = meta['detail_url']
        #print("首页的每一个新闻url:", item['title_url'])

        # 首页页面的时间
        item['time'] = meta['time']
        #print("首页的时间", item['time'])

        # 标题
        title = response.xpath('//td[@class="hui_15_cu"]//text()').extract_first()
        item['title'] = title
        #print("标题", item['title'])


        # 详细页面的 内容
        etree = response.xpath('//div[@id="TRS_AUTOADD"] | //div[@class="TRS_Editor"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '中国农业信息网'

        # type_no 就是 id
        item['type_no'] = None
        yield item
