import re
import json
from aip import AipNlp
import psycopg2
import re
from news.config.sql_log import log

class Deal_Content():

    def getTag(title, content):
        APP_ID = '11703996'
        API_KEY = '5TetNdgFFeWQxNbI8H4fZ8kq'
        SECRET_KEY = 'RWmPGTBdcStIiDMtb7GOGGB0PVXMCyce'

        client = AipNlp(APP_ID, API_KEY, SECRET_KEY)
        t = title.encode('gbk', 'ignore')
        if len(t)>80:
            title = t[:80].decode('gbk','ignore')
        content = content
        js = client.keyword(title, content)
        print(js)
        items = js.get('items')
        items = json.dumps(items, ensure_ascii = False)
        return items



    def handleText(noHandleText, noHandleTagText, img_urls_dict, title):
        # 处理纯文本
        handleText = noHandleText.replace(u'\n', u'').replace(u'\t', u'').replace(u'\u3000', '').replace(u'\r', u'').replace(u'\xa0', u'')  # .replace(u'')
        tags = Deal_Content.getTag(title, handleText)   #处理百度api 评价返回的方法。
        # 处理带标签的文本 图片的URL

        for img_url in img_urls_dict.keys():   #取字典名.keys 可以取到key的列表， 然后进行遍历

            noHandleTagText = noHandleTagText.replace(img_url, img_urls_dict[img_url])   # 把传过来的数据noHandleTagText（content(内容)）， 用replace替换模块把  加上(http://)的换成没有(域名的链接。)
        print('====================nohandletagtext=================', noHandleTagText)

        if re.findall(r'in-src="(.*)" data-mce-att', noHandleTagText):
            wei_chat_pic= re.findall(r'in-src="(.*)" data-mce-att', noHandleTagText)[-1]
            noHandleTagText = noHandleTagText.replace(wei_chat_pic, "")
            print("微信打印的东西",wei_chat_pic)
        return noHandleTagText, tags


    def sql_read(industry):
        id = None
        pid = None

        l = log()

        conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host,port=l.port)
        cur = conn.cursor()
        cur.execute(
            "SELECT id,pid from bjzs_big_data.baoji_industry_level where name = '{}' and level = 2 ".format(industry)
        )
        rows = cur.fetchall()
        if len(rows) != 0:
            row = rows[0]
            id = row[0]
            pid = row[1]
        conn.commit()
        cur.close()
        conn.close()
        return id, pid

    def deal_date(self,data):
        day = None
        time = None


        if len(data) == 10:
            return data
        elif len(data) == 11:
            c = "2018年" + data
            return c
        try:
            if '/' in data:
                day = re.findall('\d*/\d*/\d*', data)[0]
                time = re.findall('\d*:\d*', data)[0]
            elif '-' in data:
                day = re.findall('\d*-\d*-\d*', data)[0]
                time = re.findall('\d*:\d*', data)[0]

        except:
            pass

        data = "{} {}".format(day, time)
        return data

    def handleTime(self, newTime, indexUrl):
        print("++++++++++++++time+++++++++++++", newTime)
        if '年' in newTime or '月' in newTime or '日' in newTime:
            newTime = newTime.replace('年', '-').replace('月', '-').replace('日', '')

            if 'chyxx' in indexUrl:
                if len(newTime) == 10 or len(newTime) == 11:
                    newTime = '2018-' + newTime
                    return newTime

        #print("哇卡卡.返回的时间", newTime)
        newTime = re.search('\d.*\d', newTime).group()
        return newTime
