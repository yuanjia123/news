#China_shoping

# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class China_shoping(scrapy.Spider):
    name = 'China_shoping'
    allowed_domains = ['www.mofcom.gov.cn']    #允许的页面最好不要定义  http://  这样的

    start_urls = ['http://www.mofcom.gov.cn/article/b/']


    #中华民族共和国商务部
    def parse(self, response):
        #获取id 或者pid
        id, pid = Deal_Content.sql_read(response.url)

        #列表页面的 url

        #1、//section[@class='w1200 m-con-01']//section[2]//text()

        home_url = response.xpath("//section[@class='w1200 m-con-01']//section[2]//li/a/@href | //section[@class='w1200 m-con-01']//section[3]//li/a/@href | //section[@class='w1200 m-con-01']//section[last()]//li/a/@href").extract()

        #标题
        title = response.xpath("//section[@class='w1200 m-con-01']//section[2]//li/a/@title | //section[@class='w1200 m-con-01']//section[3]//li/a/@title | //section[@class='w1200 m-con-01']//section[last()]//li/a/@title").extract()

        #时间
        time = response.xpath("//section[@class='w1200 m-con-01']//section[2]//li/span/text() | //section[@class='w1200 m-con-01']//section[3]//li/span/text() | //section[@class='w1200 m-con-01']//section[last()]//li/span/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={"time":time[j],"title": title[j], 'id': id,'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1



    def detail_parse(self,response):

        item = NewsProjectItem()
        meta = response.meta

        #标题
        item['title'] = meta['title']
        title = meta['title']
        print('标题:', item['title'])

        #标题时间
        item['time'] = meta['time']
        print('标题时间:',item['time'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        #id
        item['id'] = 17
        print("id:",item['id'])

        #pid
        item['pid'] = 3
        print("pid:",item['pid'])

        # 详细页面的内容
        etree = response.xpath('//div[@id="zoom"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://网站" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************",item['tags'])

        #type_cn    哪个类型的网站
        item['type_cn'] = None

        #news    新闻来源、是那一个网站， 主页
        item['news'] = '中华民族共和国商务部'

        #type_no 就是 id
        item['type_no'] = None


        yield item