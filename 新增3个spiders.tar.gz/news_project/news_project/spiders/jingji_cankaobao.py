# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class jingji_cankaobao(scrapy.Spider):
    name = 'jingji_cankaobao'
    #allowed_domains = ['www.jjckb.xinhuanet.cn']    #允许的页面最好不要定义  http://  这样的

    start_urls = ['http://jjckb.xinhuanet.com/hlw.htm']


    #经济参考报
    def parse(self, response):
        #获取id 或者pid
        id, pid = Deal_Content.sql_read(response.url)

        #列表页面的 url
        home_url = response.xpath("//ul[@class='xpage-content-list']/li/a/@href").extract()

        #标题
        title = response.xpath("//ul[@class='xpage-content-list']/li/a/text()").extract()

        #时间
        time = response.xpath("//ul[@class='xpage-content-list']/li/span/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            print("详细页面的网址,:",detail_url)
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time': time[j], "title": title[j], 'id': id,'pid': pid},dont_filter=True)  # 进入详细页面
            j += 1



    def detail_parse(self,response):

        item = NewsProjectItem()
        meta = response.meta

        #标题
        item['title'] = meta['title']
        title = meta['title']
        print('标题:', item['title'])

        #标题时间
        item['time'] = meta['time']
        print('标题时间:',item['time'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        #id
        item['id'] = meta['id']
        print("id:",item['id'])

        #pid
        item['pid'] = meta['pid']
        print("pid:",item['pid'])

        # 详细页面的内容


        etree = response.xpath('.//div[@class = "mainCon"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************",item['tags'])

        #print(self.p)
        item['type_cn'] = '互联网+'

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '经济参考报'

        # type_no 就是 id
        item['type_no'] = 15
        yield item