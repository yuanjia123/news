#shanxi_people_government
# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class shanxi_people_government(scrapy.Spider):
    name = 'shanxi_people_government'
    allowed_domains = ['www.shaanxi.gov.cn']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://www.shaanxi.gov.cn/info/iList.jsp?cat_id=17477','http://www.shaanxi.gov.cn/sxxw/xwtt/df/129085.htm']


    #中华民族共和国商务部
    def parse(self, response):
        #获取id 或者pid
        id, pid = Deal_Content.sql_read(response.url)

        #列表页面的 url

        home_url = response.xpath("//ul[@class='xwlist-ul']//li/a/@href").extract()
        print("home_url---------------------",home_url)
        #标题
        #title = response.xpath("//section[@class='w1200 m-con-01']//section[2]//li/a/@title | //section[@class='w1200 m-con-01']//section[3]//li/a/@title | //section[@class='w1200 m-con-01']//section[last()]//li/a/@title | //ul[@id='list']//li/text()").extract()

        #时间
        time = response.xpath("//ul[@class='xwlist-ul']//li/span/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={"time":time[j], 'id': id,'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1



    def detail_parse(self,response):

        item = NewsProjectItem()
        meta = response.meta

        #标题
        item['title'] = response.xpath("//h1/text()").extract_first()
        title = item['title']
        print('标题:', item['title'])

        #标题时间
        item['time'] = meta['time']
        print('标题时间:',item['time'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        #id
        item['id'] = meta['id']
        print("id:",item['id'])

        #pid
        item['pid'] = meta['pid']
        print("pid:",item['pid'])

        # 详细页面的内容
        etree = response.xpath("//div[@class='info-cont']")
        tagContet = etree.extract()
        print("tagContettagContettagContet************",tagContet,type(tagContet))
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://网站" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************",item['tags'])

        item['type_cn'] = "省市级"

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '陕西省人民政府'

        # type_no 就是 id
        item['type_no'] = 18


        yield item