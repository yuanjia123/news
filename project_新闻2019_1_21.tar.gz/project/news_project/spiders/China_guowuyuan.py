#China_guowuyuan
# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class China_guowuyuan(scrapy.Spider):
    name = 'China_guowuyuan'
    allowed_domains = ['www.gov.cn']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://www.gov.cn/zhengce/zuixin.htm']

    #中国国务院
    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        home_url = response.xpath("//div[@class='list list_1 list_2']//a/@href").extract()

        # 标题
        title = response.xpath("//div[@class='list list_1 list_2']//a/text()").extract()

        # 时间
        time = response.xpath("//div[@class='list list_1 list_2']//span/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,
                                 meta={'time': time[j], "title": title[j], 'id': id, 'pid': pid},
                                 dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = meta['id']

        item['pid'] = meta['pid']

        # 首页的url
        item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = meta['title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = response.url
        #print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = meta['time']
        #print('标题时间',item['time'])


#----------------------------------------------------------------------------------------------------
        # 详细页面的内容
        etree = response.xpath('//td[@id="UCAP-CONTENT"] | //div[@id = "UCAP-CONTENT"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet,img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = '其他'

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '中华人民共和国中央人民政府'

        # type_no 就是 id
        item['type_no'] = 19
        yield item
