# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem


class electronic_info_net(scrapy.Spider):
    name = 'electronic_info_net'
    #allowed_domains = ['www.cena.com']    #允许的页面最好不要定义  http://  这样的
    #base_url = 'http://www.ctn1986.com'
    start_urls = ['http://www.cena.com.cn/industrynews/index.html']

    #电子信息产业网
    def parse(self, response):
        id, pid = Deal_Content.sql_read(response.url)

        list_news = response.xpath("//div[@class='main-left']//div//h2/a")
        for a in list_news:
            title_url = a.xpath("./@href").extract_first()

            title = a.xpath("./font/text()").extract_first()
            yield scrapy.Request(url=title_url, callback=self.detail_parse,meta={'title_url':title_url,"title":title,'id':id,'pid':pid},dont_filter=True)  #进入详细页面

    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = 165

        item['pid'] = 9



        # 首页的url
        item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = meta['title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = meta['title_url']
        #print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = response.xpath('//span[@class="time"]/text() | //div[@class="laiyuan"]/span/text()').extract_first()
        #print('标题时间',item['time'])


#----------------------------------------------------------------------------------------------------
        # 详细页面的内容
        etree = response.xpath('//div[@id="art_body"] | //div[@class="nr_sj"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************", item['tags'])
        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '电子信息产业网'

        # type_no 就是 id
        item['type_no'] = None

        yield item