#zhaiquanzhixing

import re
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class zhaiquanzhixing(scrapy.Spider):
    name = 'zhaiquanzhixing'
    allowed_domains = ['news.stockstar.com']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://news.stockstar.com/tag_list/%E4%BA%A7%E6%9D%83%E4%BA%A4%E6%98%93%E6%89%80.shtml']

    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        home_url = response.xpath("//div[@class='content']/ul[@class='list-line']//li/a/@href").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'id': id, 'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = 169

        item['pid'] = 10

        # 首页的url
        item['url'] = self.start_urls
        print("首页的url",item['url'])

        # 标题
        title = response.xpath('//h1/text()').extract_first()
        item['title'] = title
        print('标题',item['title'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = response.xpath("//span[@id='pubtime_baidu']/text()").extract_first()
        print('标题时间',item['time'])

#----------------------------------------------------------------------------------------------------
        #详细页面的内容
        etree = response.xpath("//div[@id='container-article']")
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet,img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '证券之星'

        # type_no 就是 id
        item['type_no'] = None

        yield item
