
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class baoji_gaoxin_technology(scrapy.Spider):
    name = 'baoji_gaoxin_technology'
    #allowed_domains = ['www.sxsdcc.cn']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://36.41.190.22/site/bjgx/483/index.html']

    #陕西省山东商会
    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        home_url = response.xpath("//div[@class='zw_conter_left3']//ul[@id='Tab0_0']//li//a/@href").extract()

        # 时间
        time = response.xpath("//div[@class='zw_conter_left3']//ul[@id='Tab0_0']//span/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time': time[j],'id': id, 'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = meta['id']

        item['pid'] = meta['pid']

        # 首页的url
        item['url'] = self.start_urls
        print("首页的url",item['url'])

        # 标题
        title = response.xpath("//div[@class='content-article center-article']/h3/text()").extract_first()
        item['title'] = title
        print('标题',item['title'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = meta['time'].replace('>','')
        print('标题时间',item['time'])

#----------------------------------------------------------------------------------------------------
        #详细页面的内容
        etree = response.xpath("//div[@class='content-article center-article']//span[@id='post1'] | //div[@class='content-article center-article']//div")
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet,img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = '协会'

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '高新区管委会'

        # type_no 就是 id
        item['type_no'] = 35

        #新增字段
        item['association_id'] = 215
        yield item
