from aip import AipNlp
import json
import re
import psycopg2
from news_project.config.sql_log import log
from news_project.settings import USER_AGENTS as us_list
import random


#随机换user-agent
class UserAgentMiddleware(object):
    """
        给每一个请求随机切换一个User-Agent
    """

    def process_request(self, request, spider):
        user_agent = random.choice(us_list)
        request.headers['User-Agent'] = user_agent


        #不请求重复项

        dict_spider = {'China_chanye_info': '中国产业信息', 'chanye_message_inter': '中国产业经济信息网', 'China_paper_net': '中国纸网',
         'guanchazhe': '观察者.十三五规划', 'China_qinggong_net': '中国轻工业网', 'fazhan_inter': '中国发展网',
         'baoji_news_inter': '宝鸡新闻网', 'touzi_zixun': '中国投资咨询网', 'China_nongye_info': '中国农业信息网',
         'China_fazhanwang': '中国发展网', 'souhu_inter': '搜狐网', 'jingji_day_newspaper': '经济日报', 'high_talk': '国家发改委网站',
         'baoji_zhaoshangju': '宝鸡招商网', 'fangzhi_online': '纺织在线', 'guihuasi': '国家发改委网站（规划司)', 'huanqiu_trade': '环球贸易网',
         'project_make': '界面', 'jingji_cankaobao': '经济参考报', 'yilu_yidai': '中国一带一路网', 'China_know_city': '中国智慧城市网',
         'China_made_medicine': '中国制药网', 'electronic_info_net': '电子信息产业网', 'baoji_news_west_voice': '西部之声',
         'zhengquan_time': '证券时报', 'xinlang_inter': '新浪网', 'location_zhengce': '中国日报', 'China_metal': '中国金属制品网',
         'wangyi': '网易', 'zhihui_city': '中国城市报','China_aviation':'中国财经首页','Water_transport':'中国水运网','He_xun_science':'和讯科技',
         'China_culture':'中国文化产业网','China_build':'中国建筑装饰网','International_energy':'国际能源网','Social_guarantee':'中国劳动保障新闻网',
         'huanqiu_international':'环球国际','Health':'中华人名共和国国家卫生健康委员会','Society_work':'中国社会科学网','Soil_society':'中华人民共和国自然资源部',
         'transport_inter':'铁路网','Tree_inter':'林业','industry_food':'职业餐饮网','Electricity':'北极星电力网首页','Education':'中华人名共和国教育部','shop_inter':'新零售网',
         'room_build':'建设行业信息网'}

        l = log()

        for key_i in dict_spider.keys():
            if spider.name == key_i:
                vocation = None
                vocation = dict_spider[key_i]

                conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)
                cur = conn.cursor()

                cur.execute(
                    "SELECT url from bjzs_big_data.baoji_news where source = '{}'".format(vocation))

                rows = cur.fetchall()

                conn.commit()
                cur.close()
                conn.close()

                have_url = []
                if len(rows) != 0:
                    for i in rows:
                        have_url.append(i[0])

                try:
                    if request.url in have_url:
                        #return False                #如果不想访问， 直接返回return False 。 process_request 默认只让返回三个 1、none 2、requests 3、response
                        return request.url
                except AssertionError:
                    pass







class Deal_Content():

    def getTag(title, content):
        APP_ID = '11703996'
        API_KEY = '5TetNdgFFeWQxNbI8H4fZ8kq'
        SECRET_KEY = 'RWmPGTBdcStIiDMtb7GOGGB0PVXMCyce'

        client = AipNlp(APP_ID, API_KEY, SECRET_KEY)
        t = title.encode('gbk', 'ignore')
        if len(t)>80:
            title = t[:80].decode('gbk','ignore')
        content = content
        js = client.keyword(title, content)
        print(js)
        items = js.get('items')
        items = json.dumps(items, ensure_ascii = False)
        return items



    def handleText(noHandleText, noHandleTagText, img_urls_dict, title):
        # 处理纯文本
        handleText = noHandleText.replace(u'\n', u'').replace(u'\t', u'').replace(u'\u3000', '').replace(u'\r', u'').replace(u'\xa0', u'')  # .replace(u'')
        tags = Deal_Content.getTag(title, handleText)   #处理百度api 评价返回的方法。
        # 处理带标签的文本 图片的URL

        for img_url in img_urls_dict.keys():   #取字典名.keys 可以取到key的列表， 然后进行遍历

            noHandleTagText = noHandleTagText.replace(img_url, img_urls_dict[img_url])   # 把传过来的数据noHandleTagText（content(内容)）， 用replace替换模块把  加上(http://)的换成没有(域名的链接。)
        print('====================nohandletagtext=================', noHandleTagText)

        if re.findall(r'in-src="(.*)" data-mce-att', noHandleTagText):                       #取下面的二维码。
            wei_chat_pic= re.findall(r'in-src="(.*)" data-mce-att', noHandleTagText)[-1]
            noHandleTagText = noHandleTagText.replace(wei_chat_pic, "")
            #print("微信打印的东西",wei_chat_pic)
        return noHandleTagText, tags


    def sql_read(industry):
        id = None
        pid = None

        l = log()

        conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host,port=l.port)
        cur = conn.cursor()
        cur.execute(
            "SELECT id,pid from bjzs_big_data.baoji_industry_level where name = '{}' and level = 2 ".format(industry)
        )
        rows = cur.fetchall()
        if len(rows) != 0:
            row = rows[0]
            id = row[0]
            pid = row[1]
        conn.commit()
        cur.close()
        conn.close()
        return id, pid

    def deal_date(self,data):
        day = None
        time = None


        if len(data) == 10:
            return data
        elif len(data) == 11:
            c = "2018年" + data
            return c
        try:
            if '/' in data:
                day = re.findall('\d*/\d*/\d*', data)[0]
                time = re.findall('\d*:\d*', data)[0]
            elif '-' in data:
                day = re.findall('\d*-\d*-\d*', data)[0]
                time = re.findall('\d*:\d*', data)[0]

        except:
            pass

        data = "{} {}".format(day, time)
        return data

    #时间检查
    def handleTime(self, newTime, indexUrl):

        if '年' in newTime or '月' in newTime or '日' in newTime:
            newTime = newTime.replace('年', '-').replace('月', '-').replace('日', '')

            if 'media.people' in indexUrl:
                newTime = re.findall('\d{4}-\d{2}-\d{2}',newTime)
                return newTime[0]

            print("***************************",newTime)
        elif 'tech.hexun' in indexUrl:
            return newTime[0]

        elif 'nhc.gov.c' in indexUrl:
            newTime = newTime.replace(' ', '')
            newTime = re.findall('\d.*\d', newTime)[0]
            return newTime

        newTime = re.search('\d.*\d', newTime).group()

        if '/' in newTime:
            newTime = newTime.replace('/','-')
            return newTime


        return newTime