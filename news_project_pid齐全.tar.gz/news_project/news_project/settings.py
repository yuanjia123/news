BOT_NAME = 'news_project'

SPIDER_MODULES = ['news_project.spiders']
NEWSPIDER_MODULE = 'news_project.spiders'

CONCURRENT_REQUESTS = 64    #并行处理的并发项目的最大数量

DOWNLOAD_DELAY = 0.2   #下载器在从同一网站下载连续页面之前应等待的时间（以秒为单位）。这可以用于限制爬行速度，以避免击中服务器太难。支持小数。例：
DOWNLOAD_TIMEOUT = 3  #下载超时

USER_AGENTS = [
            "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
            "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
            "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
            "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
            "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
            "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
            "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
            "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
            "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3192.0 Safari/537.36Name"
            ]

RETRY_ENABLED = True  #重定向， 打开就可以接受重定向的response


ROBOTSTXT_OBEY = False  #不存寻ROBOT协议

COOKIES_ENABLED = False #除非特殊需要，禁用cookies，防止某些网站根据Cookie来封锁爬虫。

DOWNLOADER_MIDDLEWARES = {
   'news_project.middlewares.UserAgentMiddleware': 543,   #下载中间键
}


ITEM_PIPELINES = {
   'news_project.pipelines.NewsProjectPipeline': 300,   #存储中间键
}

LOG_ENABLED=False  #LOG_ENABLED 默认: True，启用logging
LOG_LEVEL = 'INFO'  #LOG_LEVEL 默认: 'DEBUG'，log的最低级别
COMMANDS_MODULE = 'news_project.commands'   #设置几十个爬虫一起跑。