import psycopg2
import json
from news.config.sql_log import log
from news.middlewares import Deal_Content
class News_Pipeline(object):
    def open_spider(self, spider):
        l = self.l = log()
        self.conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)


    def process_item(self, item, spider):
        l = self.l = log()
        self.conn = psycopg2.connect(database=l.database, user=l.user, password=l.password, host=l.host, port=l.port)
        self.cur = self.conn.cursor()

        item = dict(item)
        d = Deal_Content()
        item['time'] = d.handleTime(item['time'],item['title_url']) #修改时间格式

        for i in item.keys():
            if item[i] == "" or item[i] == None:
                item[i] = None

        if item['type_cn'] == None:
            item['type_cn'] = "行业新闻"

        if item['type_no'] == None:
            item['type_no'] = 16
        self.cur.execute(
           "INSERT INTO bjzs_big_data.baoji_news(type_cn,source,level2,level1,event_time,title,url,content,lable,type_no) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(item['type_cn'],item['news'],item['id'],item['pid'],item['time'],item['title'],item['title_url'],item['content'],item['tags'],item['type_no']))
        #提交
        self.conn.commit()
        self.cur.close()
        self.conn.close()

        return item

    def close_spider(self, spider):

        self.conn.close()
