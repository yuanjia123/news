# -*- coding: utf-8 -*-
import scrapy
from news.items import NewsProjectItem
from news.middlewares import Deal_Content
import urllib.parse

class qinggongSpider(scrapy.Spider):
    name = 'huanqiu_trade'
    #allowed_domains = ['www.paper.com']    #允许的页面最好不要定义  http://  这样的
    #base_url = 'http://www.paper.com.cn'
    start_urls = ['http://info.china.herostart.com/c90003/']

    #环球贸易网
    def parse(self, response):
        id, pid = Deal_Content.sql_read(response.url)
        list_news = response.xpath("//div[@class='left_box']//li[@class='catlist_li']")
        for li in list_news:
            title_url = li.xpath("./a/@href").extract_first()
            #detail_url = self.base_url + title_url

            #print("title", li.xpath("./a/text()").extract_first())
            title = li.xpath("./a/text()").extract_first()

            #print("time", li.xpath("./span/text()").extract_first())
            time = li.xpath("./span/text()").extract_first()

            if not title_url:
                continue
            #print("详细页面的url", title_url)
            yield scrapy.Request(url=title_url, callback=self.detail_parse,meta={'time':time,'title_url': title_url,"title":title,'id':id,'pid':pid},dont_filter=True)  #进入详细页面


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = 129

        item['pid'] = 3

        # item['type_cn'] = meta['type_cn']
        #
        # item['news'] = meta['news']

        # 首页的url
        item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = meta['title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = meta['title_url']
        #print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = meta['time']
        #print('标题时间',item['time'])

        # # 详细页面的内容
        # item['content'] = response.xpath('//div[@id="article"]//p/text()').extract()
        # print('详细页面的内容',item['content'])
        # yield item



#----------------------------------------------------------------------------------------------------
        # 详细页面的内容
        etree = response.xpath('//div[@id="article"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title,)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '环球贸易网'

        # type_no 就是 id
        item['type_no'] = None

        yield item
