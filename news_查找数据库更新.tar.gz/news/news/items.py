# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class NewsProjectItem(scrapy.Item):
    # define the fields for your item here like:

    # 首页的url
    url = scrapy.Field()

    # 首页页面的标题
    title = scrapy.Field()

    # 标题的url
    title_url = scrapy.Field()

    # 标题时间
    time = scrapy.Field()

    #详细页面的内容
    content = scrapy.Field()

    #百度评分
    tags = scrapy.Field()

    #id
    id = scrapy.Field()

    #pid
    pid = scrapy.Field()

    #type_cn    哪个类型的网站
    type_cn = scrapy.Field()

    #news    新闻来源、是那一个网站， 主页
    news = scrapy.Field()

    #type_no 就是 id
    type_no = scrapy.Field()
