# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class chanyeSpider(scrapy.Spider):
    name = 'China_chanye_info'
    allowed_domains = ['www.chyxx.com']    #允许的页面最好不要定义  http://  这样的
    base_url = 'http://www.chyxx.com'

    #start_urls = ['http://www.chyxx.com/industry/yousejinshu/1.html']
    start_urls = ['http://www.chyxx.com/industry/yousejinshu/1.html','http://www.chyxx.com/industry/heisejinshu/1.html','http://www.chyxx.com/industry/yanjiu/1.html',
                  'http://www.chyxx.com/industry/yinliao/1.html','http://www.chyxx.com/industry/shipin1/1.html','http://www.chyxx.com/industry/shiyou/1.html','http://www.chyxx.com/industry/yjqt/1.html','http://www.chyxx.com/industry/feijinshu/1.html','http://www.chyxx.com/industry/fzqt/1.html','http://www.chyxx.com/industry/meitan/1.html']


    #中国产业信息
    def parse(self, response):
        id, pid = Deal_Content.sql_read(response.url)
        list_news = response.xpath("//div[@class='pageList']//ul")
        if 'yousejinshu' in response.url:
            id = 109
            pid = 2
        elif "heisejinshu" in response.url:
            id = 108
            pid = 2

        elif "yanjiu" in response.url:
            id = 115
            pid = 3
        elif 'yinliao' in response.url:
            id = 115
            pid = 3
        elif 'shipin' in response.url:
            id = 114
            pid = 3
        elif 'shiyou' in response.url:
            id = 107
            pid = 2
        elif 'yjqt' in response.url:
            id = 112
            pid = 2
        elif 'feijinshu' in response.url:
            id = 130
            pid = 3
        elif 'fzqt' in response.url:
            id = 118
            pid = 3
        elif 'meitan' in response.url:
            id = 106
            pid = 2

        for list_li in list_news:
            list_li = list_li.xpath(".//li")
            for li in list_li:
                home_url = li.xpath("./a/@href").extract_first()

                #主页标题
                home_title = li.xpath("./a/text()").extract_first()#

                #主页时间
                time = li.xpath("./span/text()").extract_first()

                #主页的页面的url
                detail_url = self.base_url + home_url

                yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time':time,'detail_url':detail_url,"home_title":home_title,'id':id,'pid':pid},dont_filter=True)  #进入详细页面



    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        # 首页的url
        #item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['home_title']
        item['title'] = meta['home_title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = meta['detail_url']
        #print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = meta['time']
        #print('标题时间',item['time'])


        item['id'] = meta['id']

        item['pid'] = meta['pid']


        # 详细页面的内容
        etree = response.xpath('//div[@id="contentBody"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************",item['tags'])

        #print(self.p)
        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '中国产业信息'

        item['type_no'] = None

        print("打印item:***********************", item)
        yield item
